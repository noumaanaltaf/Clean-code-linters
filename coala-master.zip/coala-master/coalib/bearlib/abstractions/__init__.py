"""
The abstractions package contains classes that serve as interfaces for
helper classes in the bearlib.
"""
