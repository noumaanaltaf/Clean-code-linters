from coalib.bearlib.languages.Language import Language


@Language
class JSP:
    __qualname__ = 'JavaServer Pages'
