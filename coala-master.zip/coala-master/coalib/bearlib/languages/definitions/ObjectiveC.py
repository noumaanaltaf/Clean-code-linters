from coalib.bearlib.languages.Language import Language


@Language
class ObjectiveC:
    aliases = 'objective-c',
