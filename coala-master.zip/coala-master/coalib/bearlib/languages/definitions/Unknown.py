from coalib.bearlib.languages.Language import Language


@Language
class Unknown:
    pass
