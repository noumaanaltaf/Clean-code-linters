"""
Provides facilities to extract, parse and assemble documentation comments for
different languages and documentation tools.
"""
