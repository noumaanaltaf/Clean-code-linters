from coalib.misc.Enum import enum

BEAR_KIND = enum('LOCAL', 'GLOBAL')
