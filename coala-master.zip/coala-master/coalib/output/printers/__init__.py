"""
This package holds printer objects. Printer objects are general purpose and not
tied to coala.

If you need logging capabilities please take a look at the LogPrinter object
which adds logging capabilities "for free" if used as base class for any other
printer.
"""
