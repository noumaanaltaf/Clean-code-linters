"""
The StringProcessing module contains various functions for extracting
information out of strings.

Most of them support regexes for advanced pattern matching.
"""
