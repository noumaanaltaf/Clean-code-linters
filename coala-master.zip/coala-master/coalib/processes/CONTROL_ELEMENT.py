from coalib.misc.Enum import enum

CONTROL_ELEMENT = enum('LOCAL', 'GLOBAL', 'LOCAL_FINISHED', 'GLOBAL_FINISHED')
