"""
The result_actions package holds objects deriving from ResultAction.
A ResultAction represents an action that an be applied to a result.
"""
