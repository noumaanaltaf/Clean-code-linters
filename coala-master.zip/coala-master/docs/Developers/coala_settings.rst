coala settings
==============

.. argparse::
   :module: coalib.parsing.DefaultArgParser
   :func: default_arg_parser
   :prog: coala
