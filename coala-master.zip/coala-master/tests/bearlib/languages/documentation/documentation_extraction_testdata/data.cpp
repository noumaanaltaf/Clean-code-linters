#include <stdlib.h>


/**
 * This is the main function.
 * @returns Exit code.
 *          Or any other number.
 */
int main()
{
    // Your main code here.
    return 0;
}

/** foobar
 * @param xyz
 */
int foobar(int xyz)  {
    return xyz * (1 - xyz);
}

/// Some alternate style of documentation
void alternatestyle()
{}

	/** ends instantly */
void boofar()
{
    return "foobar is happy";
}

/// Should work
///
/// even without a function standing below.
///
/// @param foo WHAT PARAM PLEASE!?
