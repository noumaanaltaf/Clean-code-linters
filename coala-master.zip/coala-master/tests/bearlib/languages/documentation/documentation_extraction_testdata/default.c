#include <stdlib.h>

/**
 * This is the main function.
 *
 * @returns Your favorite number.
 */
int main()
{
    // Nonsense comment.
    printf("hello world");
    return 3 * 0;
}

/*!
 * Preserves alignment
 * - Main item
 *   - sub item
 *     - sub sub item
 */
int myfield;

/** ABC
    Another type of comment

    ... */

/** foobar = barfoo.
 * @param x whatever...
 */
int foobar(int x) {
    return x * x - x + 1;
}

     /** line 1
      *  line2 */

    /** */
