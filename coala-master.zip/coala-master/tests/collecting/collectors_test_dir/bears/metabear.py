from bear1 import TestBear as ImportedTestBear

__additional_bears__ = [ImportedTestBear]
