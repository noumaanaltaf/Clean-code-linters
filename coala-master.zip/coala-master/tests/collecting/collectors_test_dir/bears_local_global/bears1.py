from coalib.bears.GlobalBear import GlobalBear
from coalib.bears.LocalBear import LocalBear


class Test1LocalBear(LocalBear):
    pass


class Test1GlobalBear(GlobalBear):
    LANGUAGES = {'All'}
