class test(list):

    def __init__(self, *args):
        list.__init__(self, *args)

    @staticmethod
    def method():
        pass


a = [1, 2, 3]
b = [1, 2, 4]

name = True
