from file_one import test

a = test()

name = False
