if __name__ == '__main__':
    print('test_program X')
    print('Type in a number:')
    num = input()
    print(num)
    print('Exiting program.')
