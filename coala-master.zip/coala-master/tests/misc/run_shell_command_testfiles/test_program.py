if __name__ == '__main__':
    print('test_program Z')
    print('non-interactive mode.')
    print('Exiting...')
